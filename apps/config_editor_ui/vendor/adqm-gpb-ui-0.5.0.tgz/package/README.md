# ACM / GPB React UI

React + TypeScript catalogue and reusable component library. Matches the original dark ACM reference with the approved blue GPB-inspired palette. This is a React port of the reference catalogue, not the source code of the captured production application.

## Run locally

Node.js 22+ and npm are recommended. From `react-ui/`:

```sh
npm ci
npm run dev
```

Vite prints the local URL. The catalogue preserves the original sections, fonts, dimensions and colors; tabs, fields, switches and version selection are React components.

```sh
npm run typecheck
npm test
npm run build
```

`demo-dist/` contains the standalone static React application. Deploy its contents as static files. `dist/` contains the library, TypeScript declarations, scoped stylesheet and fonts. Building requires this directory to stay inside the repository because styles are derived from the original reference CSS.

## Reuse in another React application

Create an installable package (nothing is published to npm):

```sh
npm pack
# In the consuming project:
npm install /absolute/path/to/adqm-gpb-ui-0.5.0.tgz
```

React and React DOM are peer dependencies, not bundled copies. React 18.3+ or 19 is required. Import styles once at the application entry point:

```tsx
import { useState } from 'react';
import { ThemeProvider, Button, TextField, Switch, Tabs, Status } from '@adqm/gpb-ui';
import '@adqm/gpb-ui/styles.css';

export function Configuration() {
  const [name, setName] = useState('adqm-production');
  const [advanced, setAdvanced] = useState(false);
  const [tab, setTab] = useState('configuration');
  return (
    <ThemeProvider theme="gpb">
      <div style={{ padding: 24, display: 'grid', gap: 16 }}>
        <Tabs label="Service sections" value={tab} onValueChange={setTab}
          items={[{ value: 'configuration', label: 'Configuration' },
                  { value: 'hosts', label: 'Hosts' }]} />
        {tab === 'configuration' ? <>
          <TextField label="Name" value={name}
            onChange={event => setName(event.target.value)}
            error={!name.trim() ? 'Name is required' : undefined} />
          <Switch label="Advanced" checked={advanced}
            onChange={event => setAdvanced(event.target.checked)} />
          <Status status="success" label="Running" />
          <Button disabled={!name.trim()} onClick={() => console.log({ name, advanced })}>
            Save
          </Button>
        </> : <p>No hosts selected.</p>}
      </div>
    </ThemeProvider>
  );
}
```

Use `theme="acm"` for the original green theme or `theme="light"` for the light GPB palette. `ThemeSwitcher` and `useThemePreference` provide the two-theme control used by both demo apps; the preference is kept in local storage for each site origin. Component styles are scoped to `.acm-theme`; light mode also sets the document background to match the wrapper. Theme wrappers may be siblings; nesting themes is not supported. Font faces use the existing Roboto and JetBrains Mono families. CSS variables (`--acm-accent`, `--acm-page`, etc.) can be overridden on a wrapper. CSS class names inside a theme belong to this library; use separate class names for host content within it.

## Extended component gallery

Open `/#/components` in either the catalogue or the standalone cluster app. The original screens are preserved; the catalogue navigation and cluster sidebar link to this separate page. All examples use local demo data, without backend requests or persistent saving.

Use the sidebar switch to choose dark or light mode. The choice persists across pages of the same app and browser origin.

The gallery includes searchable, sortable and paginated tables; line, bar and donut charts; metric cards; validated forms; selects and textareas; buttons, switches, checkboxes, radio buttons and sliders; status badges, progress bars and alerts; confirmation dialogs, notifications, empty/loading states, event timelines and disclosure panels.

Reusable exports: `DataTable<T>` with `Column<T>`, `Chart` with `ChartPoint`, `DonutChart`, `MetricCard`, `ProgressBar`, `Badge`, `Alert`, `SelectField`, `TextArea`, `RangeField`, `Modal`, `EmptyState`, `Skeleton`, and the complete `ComponentGallery`. `RangeField` is a controlled slider with a filled blue track and value chip; pass `label`, `value`, `onValueChange`, and optionally `min`, `max`, `step`, and `unit`. The checkbox/radio, timeline and disclosure examples use native HTML and scoped styles. Charts are lightweight SVG examples, not a full analytics library; table filtering, sorting and pagination are client-side.

```tsx
import { ComponentGallery } from '@adqm/gpb-ui';
import '@adqm/gpb-ui/styles.css';

// Includes its own theme wrapper. Individual components use ThemeProvider.
export const LibraryPage = () => <ComponentGallery backHref="/" backLabel="На главную" />;
```

## Base components

| Component | Main properties |
| --- | --- |
| `ThemeProvider` | `theme`, standard div props |
| `Button` | `variant`, standard button props and ref; default `type="button"` |
| `IconButton` | required `aria-label`, button props and ref |
| `TextField` | `label`, `error`, `adornment`, `focused`, standard input props and ref |
| `Switch` | `label`, `checked` / `defaultChecked`, `onChange`, `disabled`, input ref |
| `Status` | `status`, accessible text `label` |
| `Tabs` | `items`, `value`, `onValueChange`, `variant`, accessible `label` |
| `VersionCard` | `date`, `author`, `title`, `description`, `selected`, `onSelect`, `onMenu` |
| `ColorSwatch` | `label`, `color`, `token` |
| `ComponentCard` | `title`, `meta`, `wide`, `stageClassName`, children |

Also exports `tokens`, `accents` and TypeScript prop types. Tabs support arrows, Home and End; consumers render the matching content. Version selection and menu actions are independent. No API calls or original service credentials are required.

This package includes captured fonts for visual consistency. Before redistributing it externally, review the upstream font and interface asset licenses; this repository does not grant new rights to upstream assets.
